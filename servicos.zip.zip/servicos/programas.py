import os
import subprocess
from pathlib import Path
from typing import Optional


class GerenciadorProgramas:
    """
    Responsável por localizar e controlar
    programas instalados no Windows.
    """

    def __init__(self):

        self.programas = {

            "chrome": {
                "processo": "chrome.exe",
                "apelidos": (
                    "chrome",
                    "google chrome",
                ),
                "caminhos": (
                    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                    r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
                ),
            },

            "edge": {
                "processo": "msedge.exe",
                "apelidos": (
                    "edge",
                    "microsoft edge",
                ),
                "caminhos": (
                    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                ),
            },

            "firefox": {
                "processo": "firefox.exe",
                "apelidos": (
                    "firefox",
                    "mozilla",
                ),
                "caminhos": (
                    r"C:\Program Files\Mozilla Firefox\firefox.exe",
                ),
            },

            "vscode": {
                "processo": "Code.exe",
                "apelidos": (
                    "vscode",
                    "vs code",
                    "visual studio code",
                ),
                "caminhos": (
                    r"%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe",
                ),
            },

            "spotify": {
                "processo": "Spotify.exe",
                "apelidos": (
                    "spotify",
                ),
                "caminhos": (
                    r"%APPDATA%\Spotify\Spotify.exe",
                ),
            },

            "word": {
                "processo": "WINWORD.EXE",
                "apelidos": (
                    "word",
                ),
                "caminhos": (
                    r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
                ),
            },

            "excel": {
                "processo": "EXCEL.EXE",
                "apelidos": (
                    "excel",
                ),
                "caminhos": (
                    r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE",
                ),
            },

            "powerpoint": {
                "processo": "POWERPNT.EXE",
                "apelidos": (
                    "powerpoint",
                    "power point",
                ),
                "caminhos": (
                    r"C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE",
                ),
            },

            "bloco de notas": {
                "processo": "notepad.exe",
                "apelidos": (
                    "bloco de notas",
                    "notepad",
                ),
                "caminhos": (
                    "notepad.exe",
                ),
            },

            "calculadora": {
                "processo": "CalculatorApp.exe",
                "apelidos": (
                    "calculadora",
                    "calc",
                ),
                "caminhos": (
                    "calc.exe",
                ),
            },
        }

    # --------------------------------------------------

    def identificar(
        self,
        texto: str
    ) -> Optional[str]:

        texto = texto.lower()

        candidatos = []

        for nome, dados in self.programas.items():

            for apelido in dados["apelidos"]:

                candidatos.append(
                    (
                        apelido,
                        nome
                    )
                )

        candidatos.sort(
            key=lambda x: len(x[0]),
            reverse=True
        )

        for apelido, nome in candidatos:

            if apelido in texto:
                return nome

        return None

    # --------------------------------------------------

    def abrir(
        self,
        programa: str
    ) -> bool:

        if programa not in self.programas:
            return False

        caminhos = self.programas[
            programa
        ]["caminhos"]

        for caminho in caminhos:

            caminho = os.path.expandvars(
                caminho
            )

            try:

                if (
                    caminho.endswith(".exe")
                    and "\\" not in caminho
                ):

                    subprocess.Popen(
                        [caminho]
                    )

                    return True

                if Path(
                    caminho
                ).exists():

                    os.startfile(
                        caminho
                    )

                    return True

            except Exception:
                pass

        return False

    # --------------------------------------------------

    def fechar(
        self,
        programa: str
    ) -> bool:

        if programa not in self.programas:
            return False

        processo = self.programas[
            programa
        ]["processo"]

        try:

            subprocess.run(

                [
                    "taskkill",
                    "/F",
                    "/IM",
                    processo,
                ],

                stdout=subprocess.DEVNULL,

                stderr=subprocess.DEVNULL,
            )

            return True

        except Exception:

            return False

    # --------------------------------------------------

    def reiniciar(
        self,
        programa: str
    ) -> bool:

        self.fechar(
            programa
        )

        return self.abrir(
            programa
        )

    # --------------------------------------------------

    def listar(self):

        return sorted(
            self.programas.keys()
        )


programas = GerenciadorProgramas()