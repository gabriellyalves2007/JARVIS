from dataclasses import dataclass
from enum import Enum
from typing import Optional

from ia.interpretador import interpretador
from servicos.programas import programas


class AcaoPrograma(Enum):
    ABRIR = "abrir"
    FECHAR = "fechar"
    REINICIAR = "reiniciar"
    MINIMIZAR = "minimizar"
    MAXIMIZAR = "maximizar"


@dataclass
class ComandoPrograma:
    """
    Representa um comando no formato ação + alvo.

    Exemplo:
        ação: ABRIR
        alvo: vscode
    """

    acao: AcaoPrograma
    alvo: str
    texto_original: str


class AnalisadorAcaoAlvo:
    """
    Extrai a ação e o programa mencionados
    em um comando do usuário.
    """

    PALAVRAS_ACAO = {
        AcaoPrograma.ABRIR: (
            "abra",
            "abrir",
            "abre",
            "inicie",
            "iniciar",
            "execute",
            "executar",
            "acesse",
            "acessar",
        ),

        AcaoPrograma.FECHAR: (
            "feche",
            "fechar",
            "fecha",
            "encerre",
            "encerrar",
            "finalize",
            "finalizar",
        ),

        AcaoPrograma.REINICIAR: (
            "reinicie",
            "reiniciar",
            "reabra",
            "reabrir",
        ),

        AcaoPrograma.MINIMIZAR: (
            "minimize",
            "minimizar",
        ),

        AcaoPrograma.MAXIMIZAR: (
            "maximize",
            "maximizar",
        ),
    }

    def analisar(
        self,
        comando: str
    ) -> Optional[ComandoPrograma]:
        texto_original = str(comando).strip()

        if not texto_original:
            return None

        texto = interpretador.interpretar(
            texto_original
        )

        acao = self._identificar_acao(
            texto
        )

        if acao is None:
            return None

        alvo = programas.identificar(
            texto
        )

        if alvo is None:
            return None

        return ComandoPrograma(
            acao=acao,
            alvo=alvo,
            texto_original=texto_original
        )

    def eh_comando_programa(
        self,
        comando: str
    ) -> bool:
        return self.analisar(comando) is not None

    def _identificar_acao(
        self,
        texto: str
    ) -> Optional[AcaoPrograma]:
        for acao, palavras in self.PALAVRAS_ACAO.items():
            if any(
                palavra in texto
                for palavra in palavras
            ):
                return acao

        return None


analisador_acao_alvo = AnalisadorAcaoAlvo()